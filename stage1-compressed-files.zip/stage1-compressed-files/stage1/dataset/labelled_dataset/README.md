
### Entity Type
* Location

### Tag Description
* Locations are mentioned in the documents using **\<location\>....\</location\>** tags.


### Tag Examples

#### Positives
1. He recently moved to the \<location\>United States\</location\>.
2. The climate in \<location\>India\</location\> was pleasant that year.
3. The lady claimed to be from \<location\>Europe\</location\>.

#### Negatives
1. University of Southern California
2. California's economy
3. Hollywood star
